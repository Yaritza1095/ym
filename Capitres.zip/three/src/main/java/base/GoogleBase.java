package base;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import automation.GooglePO;
import utils.DriverBase;


public class GoogleBase {
	
	private DriverBase driver;
	GooglePO po;
	
	public GoogleBase(){
		
		driver = new DriverBase(new ChromeDriver());
		po = new GooglePO(driver.getDriver());
	}
	
	public void BrowseGoogle(){
		
		driver.openSite("http://google.com");
		
	}
	
	public void SearchGoogle (String search) {
		
		po.getSearchBar().sendKeys(search);
		po.getSubmitButton().click();
	}
	
	public void clickOptionOne() {
		
		driver.delatedClick(po.getOptionOne());
	}
	
	public void close() {
		driver.close();
	}

}
