package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GooglePO {
	
	private WebDriver driver;
	
	public GooglePO(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public WebElement getSearchBar() {
		WebElement elementSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementSearchBar;
	}
	
	public WebElement getSubmitButton(){
		
		
		WebElement elementSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]")).get(0);
		return elementSubmitButton;
		
	}
	public WebElement getOptionOne(){
		
		WebElement elementSearchOption = driver.findElements(By.xpath("//h2[contains(text(), 'Resultados')]/../div/div/div/div/div/a/h3")).get(0);
		return elementSearchOption;
	}

}
