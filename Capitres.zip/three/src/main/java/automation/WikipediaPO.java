package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WikipediaPO {
	private WebDriver driver;
	
	public WikipediaPO(WebDriver driver) {
		
		this.driver = driver;
	}
	
	public WebElement getPrintTitle() {
		WebElement elementPrintTitle = driver.findElement(By.xpath("//span[@id='Historia']"));
		return elementPrintTitle;
	}
	
	public WebElement getPrintHistory(){
		WebElement elementPrintHistory = driver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div/p[2])]"));
		return elementPrintHistory;
	}
	

}
