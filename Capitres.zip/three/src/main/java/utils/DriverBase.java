package utils;

import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DriverBase {
	private WebDriver driver;
	public DriverBase(WebDriver driver) {
		Objects.requireNonNull(driver);
		this.driver = driver;
	}
	
	public void close() {
		driver.quit();
		driver = null;
	}
	
	public void delatedClick(WebElement element) {
		try {
			Thread.sleep(1000);
			element.click();
		}catch (InterruptedException i) {
			i.printStackTrace();
		}
	}
	
	public void openSite (String URL) {
		driver.get(URL);
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	

}
