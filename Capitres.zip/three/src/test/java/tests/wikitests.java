package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import base.GoogleBase;

public class wikitests {
	
	GoogleBase base;
	
	static {
		
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/driver/chromedriver.exe");
		
	}
	
	@Before
	
	public void init() {
		base = new GoogleBase();
	}
	
	@After
	
	public void CloseDriver() {
		
		base.close();
		
	}
	
	@Test
	
	public void wikitest(){
		
		base.BrowseGoogle();
		base.SearchGoogle("Selenium wikipedia");
		base.clickOptionOne();
	}

}
