package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GooglePO {
	private WebDriver driver;
	private WebDriverWait wait;

	public GooglePO(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}
	public WebElement getSearchBar() {
		WebElement elementSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementSearchBar;
	}
	public WebElement getSubmitButton() {
		WebElement elementSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]")).get(0);
		return wait.until(ExpectedConditions.elementToBeClickable(elementSubmitButton));

	}
	public WebElement getSearchOption() {
		WebElement elementSearchOption = driver.findElement(By.xpath("//h2[contains(text(), 'Resultados')]/../div/div/div/div/div/a/h3"));
		return elementSearchOption;
	}
	

}


