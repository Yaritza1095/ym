package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class StackOverFlowPo {
	private WebDriver driver;

	public StackOverFlowPo(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getSearchBarSO() {
		
		WebElement elementSearchBarSO = driver.findElement(By.xpath("//input[@placeholder='Search�']"));
		return elementSearchBarSO;
		
	}
	public WebElement getOptionSO() {
		
		WebElement elementSearchOptionSO = driver.findElements(By.xpath("//*[@class='question-hyperlink']")).get(1);
		
			return elementSearchOptionSO;
	}

	public WebElement printQuestion(){
		WebElement elementQuestion = driver.findElements(By.xpath("//*[@class='answer']")).get(0);
		return elementQuestion;
		
	}
	public WebElement printAnswer(){
		WebElement elementAnswer = driver.findElements(By.xpath("//*[@class='answer']")).get(0);
		return elementAnswer;
	}

}
