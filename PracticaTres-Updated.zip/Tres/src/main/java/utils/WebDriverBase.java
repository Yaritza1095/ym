package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriverBase {
	private static WebDriver driver;
	
	/*
	 * Inicializa el WebDrivver
	 */
	
	public WebDriver initChrome() {
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
		return driver;
		
	}
	
	public void closeDriver() {
		driver.quit();
		driver = null;
	}
	
	public void browse (String url) {
		driver.get(url);
	}
	
	public WebDriver getDriver() {
		return driver;
	}

}
