package base;

import org.openqa.selenium.WebDriver;

import pageObjects.GooglePO;

public class GoogleBase {
	private final String URL = "http://google.com";
	private WebDriver driver;
	
	public GoogleBase(WebDriver driver) {
		this.driver = driver;
	}
	public void BrowseGoogle() {
		System.out.println("Going to: " + URL);
		driver.get(URL);
	}
	public void SearchGoogle(String search) {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchBar().sendKeys(search);
		pageObject.getSubmitButton().click();
	}

	public void ClickResult() {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchOption().click();
	}

}
