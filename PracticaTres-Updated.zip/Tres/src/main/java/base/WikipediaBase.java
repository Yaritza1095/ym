package base;

import org.openqa.selenium.WebDriver;

import pageObjects.WikipediaPO;

public class WikipediaBase {
	private WebDriver driver;

	public WikipediaBase(WebDriver driver) {
		this.driver = driver;
	}
	public void Title() {
		WikipediaPO PageObject = new WikipediaPO(driver);
		System.out.println(PageObject.getPrintTitle().getText());
		
	}
	
	public void seleniumHistory() {
		WikipediaPO PageObject = new WikipediaPO(driver);
		System.out.println(PageObject.getPrintHistory().getText());
		
	}

}
