package base;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import pageObjects.StackOverFlowPo;

public class StackOverFlowBase {
	private WebDriver driver;
	private final String URL = "https://stackoverflow.com/";

	public StackOverFlowBase(WebDriver driver) {
		this.driver = driver;
		driver.manage().window().maximize();
	}
	public void BrowseStackOverFlow() {
		System.out.println("Going to: " + URL);
		driver.get(URL);
	}

	public void SearchStackOverflow(String search) {
		StackOverFlowPo pageObject = new StackOverFlowPo(driver);
		pageObject.getSearchBarSO().sendKeys(search, Keys.ENTER);
		
	}
public void clickOption() {
		
	StackOverFlowPo pageObject = new StackOverFlowPo(driver);
		pageObject.getOptionSO().click();
	}
					
public void Question() {
	StackOverFlowPo pageObject = new StackOverFlowPo(driver);
	System.out.println(pageObject.printQuestion().getText());
	
}
public void Answer() {
	StackOverFlowPo pageObject = new StackOverFlowPo(driver);
	System.out.println(pageObject.printAnswer().getText());
	
		
}

}
