package automation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import base.BpdBase;
import base.GoogleBase;
import base.StackOverFlowBase;
import base.WikipediaBase;
import utils.WebDriverBase;

public class Tests {
	WebDriver driver;
	WebDriverBase driverBase;

	@Before
	public void init() {
		// Runs before each test
		driverBase = new WebDriverBase();
		driver = driverBase.initChrome();
	}
	@After
	public void close() {
		// closes after each test
		driverBase.closeDriver();
	}
	@Test
	
	public void ExerciseOne() {
		GoogleBase baseG = new GoogleBase(driver);
		WikipediaBase baseW = new WikipediaBase(driver);
		baseG.BrowseGoogle();
		baseG.SearchGoogle("Selenium Java Wikipedia");
		baseG.ClickResult();
		baseW.Title();
		baseW.seleniumHistory();
	}
	@Test
	public void ExerciseTwo() {
	StackOverFlowBase baseS = new StackOverFlowBase(driver);
	baseS.BrowseStackOverFlow();
	baseS.SearchStackOverflow("Selenium Java");
	baseS.clickOption();
	baseS.Question();
	baseS.Answer();
	
}
	@Test
	
	public void ExerciseThree() {
		BpdBase baseB = new BpdBase(driver);
		baseB.BrowseBpd();
		baseB.printInfo();
	}
}
