package automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.PageObjects;
public class Wikipedia {
	
	private WebDriver driver;
	
	/*
	 * Inicializa el driver
	 */
	
	public void init() {
		
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	public void closeDriver() {
		driver.quit();
		driver = null;
	}
	
	public void browseGoogle() {
		driver.get("http://google.com");
	}
	
	public void searchGoogle(String searchW) {
		PageObjects pageObject = new PageObjects(driver);
		pageObject.getSearchBarG().sendKeys(searchW);
		
		try {
			Thread.sleep(1000);
			
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		pageObject.getSubmitButtonG().click();
	}
	
	public void clickOption() {
		
		PageObjects pageObject = new PageObjects(driver);
		pageObject.getSearchOptionG().click();
	}
	
	public void Title() {
		PageObjects PageObject = new PageObjects(driver);
		System.out.println(PageObject.getPrintTitle().getText());
		
	}
	
	public void seleniumHistory() {
		PageObjects PageObject = new PageObjects(driver);
		System.out.println(PageObject.getPrintHistory().getText());
		
	}
	
	

}
