package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GooglePO {
	
	private WebDriver driver;
	
	public GooglePO(WebDriver driver){
		this.driver = driver;
	}
	
	public WebElement getSearchBar(){
		
		WebElement elementoSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementoSearchBar;
		
	}
	
	public WebElement getGoogleImg(){
		
		WebElement elementoGoogleImg = driver.findElement(By.xpath("//div[@id = 'viewport']"));
		return elementoGoogleImg;
	}
	
	public WebElement getSubmitButton(){
		
		
		WebElement elementoSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]")).get(1);
		return elementoSubmitButton;
		
	}
	
	public WebElement getFirstOption(){
		
		WebElement elementoFirstOption = driver.findElements(By.xpath("//h3[contains(@class,'LC20lb')]")).get(0);
		return elementoFirstOption;
	}
	
	public WebElement getWikiOption(){
		
		WebElement elementoWikiOption = driver.findElement(By.xpath("//h3[contains(text(),'Wikipedia, la enciclopedia libre')]"));
		return elementoWikiOption;
	}
	
	public WebElement getWikiStory(){
		
		WebElement elementoWikiOption = driver.findElements(By.xpath("//span[@id='Historia']/..//following-sibling::p")).get(0);
		return elementoWikiOption;
	}

}
