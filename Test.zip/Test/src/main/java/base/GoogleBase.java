package base;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.GooglePO;
import pageObjects.StackOverflowPO;
import utils.WebDriverHandler;

public class GoogleBase {
	
	
	private WebDriverHandler driverHandler;
	GooglePO pageObject;
	
	public GoogleBase() {
		driverHandler = new WebDriverHandler(new ChromeDriver());
		pageObject = new GooglePO(driverHandler.getDriver());
	}
	
	public void navegarGoogle(){
		
		driverHandler.openPage("http://google.com");
		
	}
	
	public void buscarEnGoogle(String buscar){
		
		//GooglePO pageObject = new GooglePO(driverHandler.getDriver());
		pageObject.getSearchBar().sendKeys(buscar);
		pageObject.getGoogleImg().click();
		pageObject.getSubmitButton().click();
	}
	
	public void clickEnPrimeraOpcion(){
		
		//GooglePO pageObject = new GooglePO(driverHandler.getDriver());
		driverHandler.delayedClick(pageObject.getFirstOption());
		
	}
	
	public void clickEnWikipedia(){
		
		//GooglePO pageObject = new GooglePO(driverHandler.getDriver());
		driverHandler.delayedClick(pageObject.getWikiOption());
		
	}
	
	public void copiarHistoriaWiki(){
		
		//GooglePO pageObject = new GooglePO(driverHandler.getDriver());
		System.out.println("==========");
		System.out.println("HISTORIA");
		System.out.println("==========");
		System.out.println(pageObject.getWikiStory().getText());	
		
	}
	
	public void navegarStackOverflow(){
	
		driverHandler.openPage("https://stackoverflow.com");
	
	}
	
	public void buscarEnStackOverflow(String buscar){
		
		StackOverflowPO pageObject = new StackOverflowPO(driverHandler.getDriver());
		pageObject.getSearchBar().sendKeys(buscar);
		pageObject.getSearchBar().sendKeys(Keys.ENTER);
		
	}
	
	public void seleccionarSegundaPregunta(){
		
		StackOverflowPO pageObject = new StackOverflowPO(driverHandler.getDriver());
		driverHandler.delayedClick(pageObject.getSecondQuestion());
		
	}
	
	public void imprimirPrimeraRespuesta(){
		StackOverflowPO pageObject = new StackOverflowPO(driverHandler.getDriver());
		System.out.println("==============");
		System.out.println("StackOverflow");
		System.out.println("==============");
		System.out.println(pageObject.getQuestionText().getText());
		System.out.println("--------------");
		System.out.println(pageObject.getFirstAnswer().getText());
	}
	
	public void close() {
		driverHandler.close();
	}
	
}
