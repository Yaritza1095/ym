package utils;

import java.util.Objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebDriverHandler {
	
	private WebDriver driver;
	public WebDriverHandler(WebDriver driver){
		Objects.requireNonNull(driver);
		this.driver = driver;
	}
	
	public void close(){
		driver.quit();
		driver = null;
	}
	
	public void delayedClick(WebElement element){		
		try {
			Thread.sleep(1000);
			element.click();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
	
	public void openPage(String page) {
		driver.get(page);
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	
}
