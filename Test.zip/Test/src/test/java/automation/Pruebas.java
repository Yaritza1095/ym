package automation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import base.GoogleBase;

public class Pruebas {
	
	GoogleBase base;
	
	static {
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/drivers/chromedriver.exe");
	}

	@Before
	public void Initialize(){
				
		base = new GoogleBase();

	}
	
	@After
	public void CloseDriver(){
		base.close();
	}
	
	@Test 
	//Escenario: 
	//           Seleccionar primer resultado de la b�squeda.
	public void pruebaGoogle(){
		
		base.navegarGoogle();
		base.buscarEnGoogle("Klk tu dice");
		base.clickEnPrimeraOpcion();
		
	}

	@Test 
	//Escenario: 
	//           Acceder a la opci�n de Wikipedia dentro de los resultados de la b�squeda
	//	         Buscar la secci�n de "Historia"
	//	         Copiar el texto de la secci�n e imprimir en consola.
	public void pruebaWikipedia(){
		
		base.navegarGoogle();
		base.buscarEnGoogle("Selenium Java Wikipedia");
		base.clickEnWikipedia();
		base.copiarHistoriaWiki();
		
	}
	
	@Test
	//Escenario: 
	//           Acceder a StackOverflow.
	//	         Buscar la "Selenium Java" en el buscador.
	//	         Acceder a la segunda pregunta e imprimir �sta y la primera respuesta encontrada.
	public void pruebaStackOverFlow(){
		
		base.navegarStackOverflow();
		base.buscarEnStackOverflow("Selenium Java");
		base.seleccionarSegundaPregunta();
		base.imprimirPrimeraRespuesta();
		
	}
	
}
