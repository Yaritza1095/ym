package base;

import org.openqa.selenium.WebDriver;

import pageObjects.BpdPO;

public class BpdBase {
	private final String URL = "http://popularenlinea.com";
	private WebDriver driver;

	public BpdBase(WebDriver driver) {
		this.driver = driver;
	}

	public void BrowseBpd() {
		System.out.println("Going to: " + URL);
		driver.get(URL);
	}

	public void printInfo() {
		BpdPO pageObject = new BpdPO(driver);
		System.out.println(pageObject.getName().getText());
		System.out.println("---------------------------");
		System.out.println(pageObject.getInfo().getText());
	}

}
