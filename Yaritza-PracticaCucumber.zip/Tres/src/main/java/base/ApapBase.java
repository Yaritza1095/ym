package base;

import org.openqa.selenium.WebDriver;

import pageObjects.APAPpo;

public class ApapBase {
	private final String URL = "http://apap.com.do";
	private WebDriver driver;
    
	public ApapBase(WebDriver driver) {
		this.driver = driver;
		//driver.manage().window().maximize();
	}

	public void BrowseApap() {
		System.out.println("Going to: " + URL);
		driver.get(URL);
	}
	
	public void clickPrestamo() {
		APAPpo pageObjects = new APAPpo(driver);
		pageObjects.getPrestamo().click();
	}
	
	public void DisplayContenido() {
		APAPpo pageObjects = new APAPpo(driver);
		System.out.println(pageObjects.getInfo().getText());
	}

}
