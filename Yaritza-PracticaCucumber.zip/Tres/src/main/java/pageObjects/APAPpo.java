package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class APAPpo {
	private WebDriver driver;
	private WebDriverWait wait;

	public APAPpo(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
		
	}
	
	public WebElement getPrestamo() {
		WebElement elementPrestamo = driver.findElement(By.xpath("//*[@id=\"slide-prestamos\"]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elementPrestamo);
		return wait.until(ExpectedConditions.elementToBeClickable(elementPrestamo));
	}
	
	public WebElement getInfo() {
		WebElement elementInfo = driver.findElement(By.xpath("//*[@id=\"offers\"]/div/div/div/div[3]/div/ul/li[5]/div/div"));
		
		return elementInfo;

	

}
}
