package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BpdPO {
	private WebDriver driver;

	public BpdPO(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getName() {
		WebElement elementName = driver.findElement(By.xpath("//h3[contains(text(),'#ORBITPOPULAR')]"));
		return elementName;
	}

	public WebElement getInfo() {
		WebElement elementInfo = driver.findElement(By.xpath("//h3[contains(text(),'#ORBITPOPULAR')]/..//following-sibling::p"));
		return elementInfo;
	}

}
