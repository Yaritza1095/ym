package stepDefinitions;

import org.openqa.selenium.WebDriver;

import base.BpdBase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import utils.WebDriverBase;

public class BPDstepsDefinitions {
	WebDriver driver = null;
	@Given("Abro el Browser")
	public void abro_el_navegador() {
		WebDriverBase base = new WebDriverBase();
		
		driver = base.initChrome();
		
		
		
	}
	
	@Given("Entro en URL")
	public void Entro_en_URL() {
		BpdBase BaseP = new BpdBase(driver);
		BaseP.BrowseBpd();
	}
	@Then("imprimo informacion Orbit")
	public void Imprimo_Info() {
		BpdBase BaseP = new BpdBase(driver);
		BaseP.printInfo();
		
	}
	
	@And("Cierro el Browser")
	public void Cierro_el_navegador() {
		driver.close();
		
	}
}

