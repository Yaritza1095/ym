package stepDefinitions;

import org.openqa.selenium.WebDriver;

import base.GoogleBase;
import base.WikipediaBase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import utils.WebDriverBase;

public class GoogleSteps {
	WebDriver driver = null;
	@Given("abro el navegador")
	public void abro_el_navegador() {
		WebDriverBase base = new WebDriverBase();
		
		driver = base.initChrome();
		
		
		
	}
	
	@Given("Yo entro a Google")
		public void yo_abro_google(){
		GoogleBase base = new GoogleBase(driver);
		base.BrowseGoogle();
	

}
	
	@Then("Busco lo que quiero")
	
	public void busco_lo_que_sea() {
		GoogleBase base = new GoogleBase(driver);
		base.SearchGoogle("Selenium Wikipedia");
		
	}
	
	@And("Click a Wikipedia")
	public void abro_wiki() {
		
		GoogleBase base = new GoogleBase(driver);
		base.ClickResult();
	}
	
	@Then("imprimo Titulo")
	public void imprimo_titulo(){
		
		WikipediaBase baseW = new WikipediaBase(driver);
		baseW.Title();
		
	}
	@Then("imprimo Historia")
	public void imprimo_hist(){
		
		WikipediaBase baseW = new WikipediaBase(driver);
		baseW.seleniumHistory();
		
	}
	@And("Cierro el navegador")
	public void cierro_nav() {
		
		driver.close();
 	}
}