package stepDefinitions;

import org.openqa.selenium.WebDriver;

import base.ApapBase;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import utils.WebDriverBase;

public class APAPSteps {
	WebDriver driver = null;
	@Given("Abro Chrome")
	public void abro_el_navegador() {
		WebDriverBase base = new WebDriverBase();
		
		driver = base.initChrome();
		
		
		
	}
	
	@Given("Entro en Link")
	public void Entro_en_URL() {
		ApapBase BaseA = new ApapBase(driver);
		BaseA.BrowseApap();
	}
	
	@Then("Click en Prestamos")
	public void Click() {
		ApapBase BaseA = new ApapBase(driver);
		BaseA.clickPrestamo();
		
	}
	@And("imprimo informacion Prestamos")
	public void Imprimo_Info() {
		ApapBase BaseA = new ApapBase(driver);
		BaseA.DisplayContenido();;
		
	}
	
	@And("Cierro Chrome")
	public void Cierro_el_navegador() {
		driver.close();
		
	}

}
