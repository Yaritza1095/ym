$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/java/features/APAP.feature");
formatter.feature({
  "name": "Buscando en APAP",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@General"
    }
  ]
});
formatter.scenario({
  "name": "Busqueda en APAP",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@General"
    },
    {
      "name": "@APAP"
    }
  ]
});
formatter.step({
  "name": "Abro Chrome",
  "keyword": "Given "
});
formatter.match({
  "location": "APAPSteps.abro_el_navegador()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Entro en Link",
  "keyword": "Given "
});
formatter.match({
  "location": "APAPSteps.Entro_en_URL()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Click en Prestamos",
  "keyword": "Then "
});
formatter.match({
  "location": "APAPSteps.Click()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "imprimo informacion Prestamos",
  "keyword": "And "
});
formatter.match({
  "location": "APAPSteps.Imprimo_Info()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Cierro Chrome",
  "keyword": "And "
});
formatter.match({
  "location": "APAPSteps.Cierro_el_navegador()"
});
formatter.result({
  "status": "passed"
});
});