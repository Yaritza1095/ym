package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.GooglePO;

public class GoogleBase {

	private WebDriver driver;
	
	/*
	 * Inicializa el driver
	 */
	public void init() {
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	public void closeDriver() {
		driver.quit();
		driver = null;
	}
	
	public void navegarGoogle() {
		driver.get("http://google.com");
	}
	
	public void buscarEnGoogle(String buscar) {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchBar().sendKeys(buscar);
		
		//TEMPORAL: PENDIENTE DE REMOVER - ADICIONANDO TIEMPO
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		pageObject.getSubmitButton().click();
	}
	
	public void clickEnlaOpcion() {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchOption().click();
	}
}
