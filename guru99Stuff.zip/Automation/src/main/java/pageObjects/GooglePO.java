package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GooglePO {
	private WebDriver driver;
	public GooglePO(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getSearchBar() {
		
		WebElement elementoSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementoSearchBar;
		
	}
	
	public WebElement getSubmitButton() {
		
		WebElement elementoSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]")).get(0);
		return elementoSubmitButton;
	}
	
	public WebElement getSearchOption() {
		
		WebElement elementoSearchOption = driver.findElement(By.xpath("//h2[contains(text(), 'Resultados')]/../div/div/div/div/div/a/h3"));
		return elementoSearchOption;
	}
	
	

}
