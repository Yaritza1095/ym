package GoogleBase;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import pageObjects.GooglePO;
public class GoogleBase {
	private WebDriver driver;
	/*
	 * Inicializa el driver
	 */
	
	public void init(){
		
		System.setProperty("webdriver.chrome.driver", "c:\\Users\\ymiranda\\workspace\\Automation\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		
		
	}
	
	public void closeDriver(){
		
		driver.quit();
		driver = null;
		
	}
	
	public void navegarGoogle(){
		
		driver.get("http://google.com");
		
		
	}
	
	public void buscarEnGoogle(String buscar){
		
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchBar().sendKeys(buscar);
		
		//TEMPORAL PENDIENTE DE REMOVER - ADICIONAR TIEMPO
		
		try {
			Thread.sleep(1000);
			
		}catch(InterruptedException e) {
			
			e.printStackTrace();
		}
		
		pageObject.getSubmitButton().click();
		
		
	
		
	}
	
	public void clickEnLaOpcion() {
		
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchOption().click();
	}

}
