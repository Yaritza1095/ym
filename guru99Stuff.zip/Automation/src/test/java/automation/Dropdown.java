package automation;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {
	@Test
	public void main(){
        WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://demo.guru99.com/test/newtours/register.php");
        
        Select dpCountry = new Select(driver.findElement(By.xpath("//select[@name='country']")));
        dpCountry.selectByVisibleText("ALBANIA");
        //Selecting Items in a multiple SELECT element
        driver.get("http://jsbin.com/osebed/2");
        Select fruits = new Select(driver.findElement(By.xpath("//select[@id='fruits']")));
        fruits.selectByVisibleText("Banana");
        fruits.selectByIndex(1);
	}

}
