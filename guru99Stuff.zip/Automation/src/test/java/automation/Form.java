package automation;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Form {
    @Test

    public void maintest(){


        //declaration and instantiation of objects variables
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
        driver = new ChromeDriver();
        String baseurl = "http://demo.guru99.com/test/login.html";
        driver.get(baseurl);

        //Get the WebElement corresponding to the Email address (TextField)
        WebElement email = driver.findElement(By.xpath("//input[@id='email']"));
        // Get the WebElement corresponding to the password field
        WebElement password = driver.findElement(By.xpath("//input[@id='passwd']"));

        email.sendKeys("abc@gmail.com");
        password.sendKeys("abc1234");
        System.out.println("Text field set");
        //Deleting the values in the text box
        email.clear();
        password.clear();
        System.out.println("Text field cleared");
        //Find the submit button
        WebElement login = driver.findElement(By.xpath("//p[@class='submit']//span[1]"));
        //Using the click method to submit the form
        email.sendKeys("abc@@gmail.com");
        password.sendKeys("abc1234");
        login.click();
        System.out.println("Login Done with click");

        //using submit method to submit the form. Submit used on password field
        driver.get(baseurl);
        driver.findElement(By.xpath("//input[@id='email']")).sendKeys("abc@gmail.com");
        driver.findElement(By.xpath("//input[@id='passwd']")).sendKeys("abc1234");
        driver.findElement(By.xpath("//p[@class='submit']//span[1]")).submit();
        System.out.println("Login done with submit");
        //driver.close();
    }
}