package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageClick {
	
	public static void main(String[] args) {
		String baseUrl = "https://stackoverflow.com/questions/55914248/how-to-handel-tooltip-in-selenium-java";
		WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get(baseUrl);
        
        //Click on the Guru 99 logo on the upper left portion
        driver.findElement(By.xpath("//span[@class='-img _glyph']")).click();
        
        //Verify we are on the homepage
        
        if(driver.getCurrentUrl().equals("https://stackoverflow.com/")) {
        	System.out.println("We are back on the Home page");
        
        }else {
        	System.out.println("Not on the HomePage");
        }
        driver.close();
	}

}
