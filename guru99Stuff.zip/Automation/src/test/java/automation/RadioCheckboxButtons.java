package automation;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioCheckboxButtons {
	@Test
	
	public void main(){

        //declaration and instantiation of objects variables
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://demo.guru99.com/test/radio.html");
        WebElement radio1 = driver.findElement(By.xpath("//input[@id='vfb-7-1']"));
        WebElement radio2 = driver.findElement(By.xpath("//input[@id='vfb-7-2']"));
        //Radio Button 1 is selected
        radio1.click();
        System.out.println("Radio Button Option 1 is selected");
        // Radio button 1 is de-selected and Radio button 2 is selected
        radio2.click();
        System.out.println("Radio Button 2 Option 2 is selected");
        
        //Selecting check box
        
        WebElement option1 = driver.findElement(By.xpath("//input[@id='vfb-6-0']"));
        //This will toggle the check box
        option1.click();
        
        //check wether the check box is toggled on
        if (option1.isSelected()){
        	System.out.println("Check box is toggled on");
        	
        }else{
        	System.out.println("checkbox is toggled off");
        }
        //driver.close();
        
	}

}
