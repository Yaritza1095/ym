package automation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocaeByLinkTextAndPartialLinkText {
		@Test
		
		@Before

		public void main(){
			WebDriver driver;
			System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
	        driver = new ChromeDriver();
	        
	        driver.get("http://demo.guru99.com/test/link.html");
	        
	        driver.findElement(By.linkText("click here")).click();
	        System.out.println("title of page is: " + driver.getTitle());
		}
		
		@After
		public void second() {
			WebDriver driver;
			System.setProperty("webdriver.chrome.driver", "c:\\users\\ymiranda\\chromedriver.exe");
	        driver = new ChromeDriver();
	        
	        driver.get("http://demo.guru99.com/test/newtours");
	        String theLinkText = driver.findElement(By.partialLinkText("egis")).getText();
	        System.out.println(theLinkText);
	        
	        theLinkText = driver.findElement(By.partialLinkText("EGIS")).getText();
	        System.out.println(theLinkText);
	        driver.quit();

}
}