package automation;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import GoogleBase.GoogleBase;
public class Pruebas {
	private GoogleBase base = new GoogleBase();
	
	@Before
	
	public void inicializar() {
		
		base.init();
	
	}
	
	@After
	
	public void cerrarNavegador() {
		base.closeDriver();
	}
	
	@Test
	
	public void pruebaGoogle() {
		
		base.navegarGoogle();
		base.buscarEnGoogle("Caballo Homosexual de la monta�a");
		base.clickEnLaOpcion();
	}
			

}
