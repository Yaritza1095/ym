package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class WebDriverBase {

	private static WebDriver driver;

	/*
	 * Inicializa el WebDriver
	 */

	public WebDriver initChrome() {
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/drivers/chromedriver.exe");
		driver = new ChromeDriver();
		return driver;
	}

	public WebDriver initIE() {
		System.setProperty("webdriver.ie.driver", "./src/main/resources/drivers/iedriver.exe");
		driver = new InternetExplorerDriver();
		return driver;
	}

	public void closeDriver() {
		driver.quit();
		driver = null;
	}

	public void navegar(String url) {
		driver.get(url);
	}

	public WebDriver getDriver() {
		return driver;
	}

}
