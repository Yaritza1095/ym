package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PopularPO {
	private WebDriver driver;

	public PopularPO(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getNombreTarjeta() {
		WebElement elementoNombreTarjeta = driver.findElement(By.xpath("//h3[contains(text(),'#ORBITPOPULAR')]"));
		return elementoNombreTarjeta;
	}

	public WebElement getInfoTarjeta() {
		WebElement elementoInfoTarjeta = driver
				.findElement(By.xpath("//h3[contains(text(),'#ORBITPOPULAR')]/..//following-sibling::p"));
		return elementoInfoTarjeta;
	}

}
