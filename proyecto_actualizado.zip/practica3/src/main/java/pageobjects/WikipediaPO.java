package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WikipediaPO {
	private WebDriver driver;
	private WebDriverWait wait;

	public WikipediaPO(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, 10);
	}

	public WebElement getSearchBar() {
		WebElement elementoSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementoSearchBar;
	}

	public WebElement getSubmitButton() {
		WebElement elementoSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]"))
				.get(0);
		return wait.until(ExpectedConditions.elementToBeClickable(elementoSubmitButton));

	}

	public WebElement getHistory() {
		WebElement elementoHistory = driver
				.findElement(By.xpath("//h2/span[text()='Historia']/..//following-sibling::p[1]"));
		return elementoHistory;
	}

}
