package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class StackOverflowPO {
	private WebDriver driver;

	public StackOverflowPO(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getSearchBar() {
		WebElement elementoSearchBar = driver.findElement(By.xpath("//input[@aria-controls='top-search']"));
		return elementoSearchBar;
	}

	public WebElement getSecondQuestion() {
		WebElement elementoSecondQuestion = driver.findElements(By.xpath("//div[@class='results-link']//a")).get(1);
		return elementoSecondQuestion;
	}

	public WebElement getQuestionText() {
		WebElement elementoQuestionText = driver.findElement(By.xpath("//a[@class='question-hyperlink']"));
		return elementoQuestionText;
	}

	public WebElement getFirstAnswer() {
		WebElement elementoFirstAnswer = driver.findElements(By.xpath("//pre[contains(@class,'pretty')]")).get(2);
		return elementoFirstAnswer;
	}
}
