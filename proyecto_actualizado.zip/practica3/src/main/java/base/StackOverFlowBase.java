package base;

import org.openqa.selenium.WebDriver;

import pageobjects.StackOverflowPO;

public class StackOverFlowBase {

	private WebDriver driver;
	private final String URL = "https://stackoverflow.com/questions";

	public StackOverFlowBase(WebDriver driver) {
		this.driver = driver;
	}

	public void navegarStackOverFlow() {
		System.out.println("Navegando  a: " + URL);
		driver.get(URL);
	}

	public void buscarEnStackOverflow(String buscar) {
		StackOverflowPO pageObject = new StackOverflowPO(driver);
		pageObject.getSearchBar().sendKeys(buscar);
		pageObject.getSearchBar().submit();
	}

}
