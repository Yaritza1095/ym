package base;

import org.openqa.selenium.WebDriver;
import pageobjects.WikipediaPO;

public class WikipediaBase {
	private WebDriver driver;

	public WikipediaBase(WebDriver driver) {
		this.driver = driver;
	}

	public void imprimirHistoria() {
		WikipediaPO pageObject = new WikipediaPO(driver);
		System.out.println("Historia");
		System.out.println(pageObject.getHistory().getText());
	}

}
