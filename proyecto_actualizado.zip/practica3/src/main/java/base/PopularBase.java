package base;

import org.openqa.selenium.WebDriver;

import pageobjects.PopularPO;

public class PopularBase {
	private final String URL = "http://popularenlinea.com";
	private WebDriver driver;

	public PopularBase(WebDriver driver) {
		this.driver = driver;
	}

	public void navegarPopular() {
		System.out.println("Navegando  a: " + URL);
		driver.get(URL);
	}

	public void imprimirInfoTarjeta() {
		PopularPO pageObject = new PopularPO(driver);
		System.out.println(pageObject.getNombreTarjeta().getText());
		System.out.println("---------------------------");
		System.out.println(pageObject.getInfoTarjeta().getText());
	}

}
