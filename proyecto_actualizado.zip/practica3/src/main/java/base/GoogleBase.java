package base;

import org.openqa.selenium.WebDriver;
import pageobjects.GooglePO;

public class GoogleBase {

	private final String URL = "http://google.com";
	private WebDriver driver;

	public GoogleBase(WebDriver driver) {
		this.driver = driver;
	}

	public void navegarGoogle() {
		System.out.println("Navegando  a: " + URL);
		driver.get(URL);
	}

	public void buscarEnGoogle(String buscar) {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchBar().sendKeys(buscar);
		pageObject.getSubmitButton().click();
	}

	public void clickEnLaOpcion() {
		GooglePO pageObject = new GooglePO(driver);
		pageObject.getSearchOption().click();
	}

}
