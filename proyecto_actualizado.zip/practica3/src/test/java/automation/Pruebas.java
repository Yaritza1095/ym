package automation;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import base.GoogleBase;
import base.PopularBase;
import base.StackOverFlowBase;
import base.WikipediaBase;
import utils.WebDriverBase;

public class Pruebas {

	WebDriver driver;
	WebDriverBase driverBase;

	@Before
	public void inicializar() {
		// ESTE METODO CORRE ANTES DE CADA TEST
		driverBase = new WebDriverBase();
		driver = driverBase.initChrome();
	}

	@After
	public void cerrarNavegador() {
		// ESTE METODO CORRE DESPUES DE CADA TEST
		driverBase.closeDriver();
	}

	@Test
	public void pruebaGoogle() {
		GoogleBase gbase = new GoogleBase(driver);
		WikipediaBase wbase = new WikipediaBase(driver);
		gbase.navegarGoogle();
		gbase.buscarEnGoogle("selenium Java Wikipedia");
		gbase.clickEnLaOpcion();
		wbase.imprimirHistoria();
	}

	@Test
	public void pruebaStackOverflow() {
		StackOverFlowBase sbase = new StackOverFlowBase(driver);
		sbase.navegarStackOverFlow();
		sbase.buscarEnStackOverflow("Selenium Java");
		// FALTA PARTE DE LA TAREA
	}

	@Test
	public void Popular() {
		PopularBase pbase = new PopularBase(driver);
		pbase.navegarPopular();
		pbase.imprimirInfoTarjeta();
	}

}
