package tests;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import automation.StackOverFlow;;
public class SOtest {
	private StackOverFlow searchSO = new StackOverFlow();	
	@Before
	
	public void initialize() {
		
		searchSO.init();
	
	}
	
	@After
	
	public void close() {
		searchSO.closeDriver();
	}
	
	@Test
	
	public void results() {
		
		searchSO.browseSO();
		searchSO.searchSO("Selenium Java");
		searchSO.clickOption();
		searchSO.Question();
		searchSO.Answer();
	    
	}
			

}