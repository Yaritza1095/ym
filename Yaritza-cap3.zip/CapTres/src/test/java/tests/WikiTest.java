package tests;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import automation.Wikipedia;
public class WikiTest {
	private Wikipedia searchW = new Wikipedia();	
	@Before
	
	public void initialize() {
		
		searchW.init();
	
	}
	
	@After
	
	public void close() {
		searchW.closeDriver();
	}
	
	@Test
	
	public void results() {
		
		searchW.browseGoogle();
		searchW.searchGoogle("Selenium Java Wikipedia");
		searchW.clickOption();
		searchW.Title();
		searchW.seleniumHistory();
	}
			

}