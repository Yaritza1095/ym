package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class PageObjects {
	private WebDriver driver;
	public PageObjects(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getSearchBarG() {
		
		WebElement elementSearchBar = driver.findElement(By.xpath("//input[@title='Buscar']"));
		return elementSearchBar;
		
	}
	
	public WebElement getSubmitButtonG() {
		
		WebElement elementSubmitButton = driver.findElements(By.xpath("//input[contains(@value, 'Buscar con')]")).get(0);
		return elementSubmitButton;
	}
	
	public WebElement getSearchOptionG() {
		
		WebElement elementSearchOption = driver.findElement(By.xpath("//h2[contains(text(), 'Resultados')]/../div/div/div/div/div/a/h3"));
		return elementSearchOption;
	}
	public WebElement getPrintTitle() {
		WebElement elementPrintTitle = driver.findElement(By.xpath("//span[@id='Historia']"));
		return elementPrintTitle;
	}
	
	public WebElement getPrintHistory(){
		WebElement elementPrintHistory = driver.findElement(By.xpath("//p[contains(text(),'Selenium fue originalmente desarrollado por Jason')]"));
		return elementPrintHistory;
	}
	
public WebElement getSearchBarSO() {
		
		WebElement elementSearchBarSO = driver.findElement(By.xpath("//input[@placeholder='Search�']"));
		return elementSearchBarSO;
		
	}
public WebElement getOptionSO() {
	
	WebElement elementSearchOptionSO = driver.findElements(By.xpath("//*[@class='question-hyperlink']")).get(1);
	
		return elementSearchOptionSO;
}

public WebElement printQuestion(){
	WebElement elementQuestion = driver.findElement(By.xpath("//*[@id=\"question-header\"]/h1/a"));
	return elementQuestion;
	
}
public WebElement printAnswer(){
	WebElement elementAnswer = driver.findElement(By.xpath("//*[@id=\"question\"]/div[2]/div[2]/div[1]"));
	return elementAnswer;

}
}