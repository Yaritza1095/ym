package automation;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import pageObjects.PageObjects;

public class StackOverFlow {
	
	private WebDriver driver;
	
	/*
	 * Inicializa el driver
	 */
	
	public void init() {
		
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/driver/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		

	}
	
	public void closeDriver() {
		driver.quit();
		driver = null;
	}
	
	public void browseSO() {
		driver.get("https://stackoverflow.com/");
	}
	
	public void searchSO(String searchSO) {
		PageObjects pageObject = new PageObjects(driver);
		pageObject.getSearchBarSO().sendKeys(searchSO, Keys.ENTER);
		
		try {
			Thread.sleep(1000);
			
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
	}
public void clickOption() {
		
		PageObjects pageObject = new PageObjects(driver);
		pageObject.getOptionSO().click();
	}
					
public void Question() {
	PageObjects PageObject = new PageObjects(driver);
	System.out.println(PageObject.printQuestion().getText());
	
}
public void Answer() {
	PageObjects PageObject = new PageObjects(driver);
	System.out.println(PageObject.printAnswer().getText());
	
		
}
}
	



